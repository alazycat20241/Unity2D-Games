using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Track : MonoBehaviour
{
    public enum TrackColor { Red, Orange, Yellow, Blue }
    public TrackColor trackColor;

    private SpriteRenderer spriteRenderer;
    private static List<Track> wrongTracks = new List<Track>();  // ��¼�����Ĵ�����

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        UpdateColor();
    }

    void UpdateColor()
    {
        switch (trackColor)
        {
            case TrackColor.Red: spriteRenderer.color = Color.red; break;
            case TrackColor.Orange: spriteRenderer.color = new Color(1f, 0.5f, 0f); break;
            case TrackColor.Yellow: spriteRenderer.color = Color.yellow; break;
            case TrackColor.Blue: spriteRenderer.color = Color.blue; break;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!GameManager.Instance.isGameActive) return;

        if (other.CompareTag("Player"))
        {
            PlayerController player = other.GetComponent<PlayerController>();
            if (player != null)
            {
                // �����ɫ�Ƿ�ƥ��
                bool isMatch = IsColorMatch(player.currentColor);

                if (!isMatch)
                {
                    // ��ɫ��ƥ�䣬��������б�
                    wrongTracks.Add(this);

                    // �����������ﵽ2����������
                    if (wrongTracks.Count >= 2)
                    {
                        player.Die();
                        wrongTracks.Clear();
                    }
                }
                else
                {
                    // ��ɫƥ�䣬��մ����б�
                    wrongTracks.Clear();
                }
            }
        }
    }

    bool IsColorMatch(PlayerController.PlayerColor playerColor)
    {
        return (playerColor == PlayerController.PlayerColor.Red && trackColor == TrackColor.Red) ||
               (playerColor == PlayerController.PlayerColor.Orange && trackColor == TrackColor.Orange) ||
               (playerColor == PlayerController.PlayerColor.Yellow && trackColor == TrackColor.Yellow) ||
               (playerColor == PlayerController.PlayerColor.Blue && trackColor == TrackColor.Blue);
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            // �뿪���ʱ������������ڴ����б���Ƴ���
            if (wrongTracks.Contains(this))
            {
                wrongTracks.Remove(this);
            }
        }
    }
}
