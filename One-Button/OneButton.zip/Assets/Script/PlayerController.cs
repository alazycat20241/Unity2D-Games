using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("�ƶ�����")]
    public float moveSpeed = 3f;
    private Vector2 moveDirection = Vector2.right;

    [Header("��ɫ����")]
    public SpriteRenderer playerSprite;
    public Color redColor = Color.red;
    public Color orangeColor = new Color(1f, 0.5f, 0f);
    public Color yellowColor = Color.yellow;
    public Color blueColor = Color.blue;

    [Header("��ɫ����")]
    public float colorTransitionSpeed = 5f;  // ��ɫ�仯�ٶ�
    private Color targetColor;                 // Ŀ����ɫ
    private Color currentVisualColor;          // ��ǰ��ʾ����ɫ

    public enum PlayerColor { Red, Orange, Yellow, Blue }
    public PlayerColor currentColor = PlayerColor.Red;

    void Start()
    {
        currentVisualColor = redColor;
        targetColor = redColor;
        playerSprite.color = currentVisualColor;
    }

    void Update()
    {
        if (!GameManager.Instance.isGameActive) return;

        // ��һ�α�һ��ɫ
        if (Input.GetKeyDown(KeyCode.Space))
        {
            currentColor = (PlayerColor)(((int)currentColor + 1) % 4);

            // �����µ�Ŀ����ɫ
            switch (currentColor)
            {
                case PlayerColor.Red: targetColor = redColor; break;
                case PlayerColor.Orange: targetColor = orangeColor; break;
                case PlayerColor.Yellow: targetColor = yellowColor; break;
                case PlayerColor.Blue: targetColor = blueColor; break;
            }

            MusicManager.Instance.PlayClickSound();
        }

        // ƽ�����ɵ�Ŀ����ɫ
        currentVisualColor = Color.Lerp(currentVisualColor, targetColor, colorTransitionSpeed * Time.deltaTime);
        playerSprite.color = currentVisualColor;

        // ��ǰ�����Զ��ƶ�
        transform.Translate(moveDirection * moveSpeed * Time.deltaTime);
    }

    public void SetDirection(Vector2 newDirection)
    {
        moveDirection = newDirection;
    }

    public void Die()
    {
        GameManager.Instance.GameOver();
    }
}
